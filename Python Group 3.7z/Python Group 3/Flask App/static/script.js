'use strict';


// global variables
let isLoggedIn = false;
let complaintNumber;
let consumerNumbers = localStorage.getItem('consumerNumbers') ? JSON.parse(localStorage.getItem('consumerNumbers')) : [] ;
let billNumbers = localStorage.getItem('billNumbers') ? JSON.parse(localStorage.getItem('billNumbers')) : []; 
let mapNumbers = localStorage.getItem('mapNumbers') ? JSON.parse(localStorage.getItem('mapNumbers')) : {}; 
let consumerNumber, billNumber, randConsumerNumber, randBillNumber;


// general functions
const getConsumerNumber = function(consumer,userid){
        for(const key in consumer){
            if(key.userID = userid){
                return key;
            }
        }
    return null;
}


// Login
const loginForm = document.getElementById('login-form');
const error = document.getElementById('error');


const updateUsers = function(e){
    e.preventDefault();

    const userID = document.getElementById('userid').value;
    const password = document.getElementById('password').value;
    const users = localStorage.getItem('users');
    const usersData = users ? JSON.parse(users) : {};
    const usersDetails = JSON.parse(localStorage.getItem('usersData'));
    let consumer = getConsumerNumber()

    if(usersData[userID]){
        if(usersData[userID] == password){
            localStorage.setItem('currentUserName',usersDetails.userName);
            isLoggedIn = true;
            window.location.href = 'home.html';
        }
        else
        error.style.display = 'block';
    } 
    else{
        error.textContent = `User doesn't exist`;
        error.style.display = 'block';
    }

    // usersData[username] = password;
    localStorage.setItem('users',JSON.stringify(usersData));
    
    // redirecting after login
   
    // console.log(usersData);
}



// Register
const registerForm = document.getElementById('register-form');
const checkPassword = document.getElementById('check-password');

const registerUsers = function(e){
    e.preventDefault();

    consumerNumber;
    billNumber = [];
    randConsumerNumber = Math.floor(Math.random*1000)+1000000000000;
    randBillNumber = Math.floor(Math.random*1000)+10000;
    if(!consumerNumbers.includes(randConsumerNumber)){
        consumerNumbers.push(randConsumerNumber);
        consumerNumber = randConsumerNumber;
    }

    if(!billNumbers.includes(randBillNumber)){
       billNumbers.push(randBillNumber);
       billNumber.push(randBillNumber);
       mapNumbers[consumerNumber] = billNumber;
    }

    // Updating to localStorage
    localStorage.setItem('consumerNumbers',JSON.stringify(consumerNumbers));
    localStorage.setItem('billNumbers', JSON.stringify(billNumbers));
    localStorage.setItem('mapNumbers',JSON.stringify(mapNumbers));
   

    const titleType = document.getElementById('title-type').value;
    const userName = document.getElementById('user-name').value;
    const userEmail = document.getElementById('user-email').value;
    const codeType = document.getElementById('code-type').value;
    const userMobile = document.getElementById('user-mobile').value;
    const userID = document.getElementById('user-id').value;
    const userPassword = document.getElementById('user-password').value;
    const userConfirmPassword = document.getElementById('user-confirm-password').value;
    const users = JSON.parse(localStorage.getItem('users'));
    const usersData = JSON.parse(localStorage.getItem('usersData')) ? JSON.parse(localStorage.getItem('usersData')) :  {} ;

    if(userPassword === userConfirmPassword){
        usersData[consumerNumber] = {'billNumber' : billNumber,'titleType' : titleType, 'userName' : userName, 'userEmail' : userEmail, 'codeType' : codeType, 'userMobile' : userMobile, 'userID' : userID};
        users[userID] = userPassword;
        localStorage.setItem('users',JSON.stringify(users));
        localStorage.setItem('usersData', JSON.stringify(usersData));
        localStorage.setItem('currentUserID',userID);
        localStorage.setItem('currentUserName',userName);
        localStorage.setItem('currenUserMobile',userMobile);
        window.location.href = 'register-success.html';
    }else{
        checkPassword.style.display = 'block';
    }
}


// Payment
const paymentForm = document.getElementById('payment-form');
// const transactionForm = document.getElementById('transaction-form');

const calculateTotal = function(){
    const checkboxes = document.querySelectorAll('.checkbox');
    let total = 0;
    for (let i = 0; i < checkboxes.length; i++) {
        if (checkboxes[i].checked) {
            let dueAmount = parseFloat(checkboxes[i].parentNode.nextElementSibling.textContent);
            total += dueAmount;
        }
    }
    document.getElementById('total-due').textContent = '₹ ' + total.toFixed(2);
    localStorage.setItem('currentTotalDue',total);
}

// const billPayment = function(e){
//     e.preventDefault();
//     // console.log('billPayment');
//     // window.location.href = 'bill-payment.html';

// }


const backToHome = () => window.location.href = 'home.html';


// Complaint
const complaintForm = document.getElementById('complaint-form');

const updateComplaints = function(e){
    e.preventDefault();

    const complaintType = document.getElementById('complaint-type').value;
    const category = document.getElementById('category').value;
    const contactPerson = document.getElementById('contact-person').value;
    const mobile = document.getElementById('mobile').value;
    const landmark = document.getElementById('landmark').value;
    const consumerNumber= document.getElementById('consumer-number');
    const problemDesc = document.getElementById('problem-desc').value;
    const address = document.getElementById('address').value;

    const complaintsData = JSON.parse(localStorage.getItem('complaintsData')) ? JSON.parse(localStorage.getItem('complaintsData')) :  {} ;
    const complaints = JSON.parse(localStorage.getItem('complaints')) ? JSON.parse(localStorage.getItem('complaints')) :  [] ;

    complaintNumber = Math.floor(Math.random() * 200 + 100);

    if(complaints.includes(complaintNumber)){
    complaintNumber = Math.floor(Math.random() * 400 + 200);
    }
    else{
        complaints.push(complaintNumber);
        complaintsData[complaintNumber] = {'complaintType': complaintType, 'category' : category,  'contactPerson' : contactPerson, 'mobile' : mobile, 'landmark' : landmark, 'consumerNumber' : consumerNumber, 'problemDesc' : problemDesc, 'address' : address};
        document.getElementById('complaint-ack').style.display = 'block';
    }
    localStorage.setItem('complaints',JSON.stringify(complaints));
    localStorage.setItem('complaintsData',JSON.stringify(complaintsData));
}


const ackMessage = function(){
    document.getElementById('complaint-ack-number').textContent = complaintNumber;
}


// Status
const complaintStatusForm =document.getElementById('complaint-status');

const complaintStatus = function(e){
    e.preventDefault()
    const  compNum = document.getElementById('complaint').value;
    const statusMsg = document.getElementById('statusMessage')
    if(compNum){
        statusMsg.textContent = 'In Progress';
        statusMsg.style.color = 'green';
        statusMsg.style.display = 'block';
    }else{
        statusMsg.textContent = 'Not found';
        statusMsg.style.color = 'red';
        statusMsg.style.display = 'block';
    }
}

// console.log(typeof JSON.parse(localStorage.getItem('complaints')) );

// let arr = ["In Progress", "Not Found", "Resolved"]

// function statusFunc(){
//     let ind  = Math.floor(Math.random())*arr.length
//     document.getElementById("statusMessage").textContent = arr[ind]
// }


window.onload=function(){
    loginForm?.addEventListener('submit',updateUsers);
    registerForm?.addEventListener('submit',registerUsers);
    // paymentForm?.addEventListener('submit',billPayment);
    complaintForm?.addEventListener('submit',updateComplaints);
    complaintStatusForm?.addEventListener('submit',complaintStatus)
    // document.querySelector('.download').addEventListener('click',downloadCurrentPage);
}

document.addEventListener('DOMContentLoaded', function() {
    // Updating total due amount in every page
    document.querySelectorAll('.payable').forEach(ele => ele.textContent ='₹ '+ Number(localStorage.getItem('currentTotalDue')).toFixed(2));

    // Updating username
    // if(isLoggedIn)
    // document.querySelector('.current-user').textContent = localStorage.getItem('currentUserName');

    // document.getElementById('rid').textContent = localStorage.getItem('currentUserID');

});