from flask import *
import sqlite3
import random
from datetime import datetime

app = Flask(__name__)
app.secret_key = "hjsfgjfgjn"

@app.route("/custview")
def custview():
    db= get_db_connection()
    cursor = db.cursor()

    cursor.execute("SELECT * FROM customers")
    cl = cursor.fetchall()

    return jsonify(cl)

@app.route("/bview")
def bview():
    db= get_db_connection()
    cursor = db.cursor()

    cursor.execute("SELECT * FROM bills")
    cl = cursor.fetchall()

    return jsonify(cl)

@app.route("/compview")
def compview():
    db= get_db_connection()
    cursor = db.cursor()

    cursor.execute("SELECT * FROM complaints")
    cl = cursor.fetchall()

    return jsonify(cl)

@app.route("/individualBills")
def individualBills():
    if not session["admin"]:
        return redirect(url_for('adminLogout'))

    db = get_db_connection()
    cursor = db.cursor()

    try:
        consumer_id = request.args.get("consumer_id")
        name = request.args.get("name")

        cursor.execute("SELECT consumer_id, bill_id, due_amount, payable_amount FROM bills WHERE consumer_id=?", (consumer_id, ))
        bills = cursor.fetchall()
        return render_template("individual-bills.html", bills = bills, name=name)

    except Exception as e:
        return str(e)
    
    finally:
        db.close()

@app.route("/bill")
def bill():
    if not session["admin"]:
        return redirect(url_for('adminLogout'))
    return render_template("seperate-bill.html")

@app.route("/seperateBill", methods=["GET", "POST"])
def seperateBill():
    if not session["admin"]:
        return redirect(url_for('adminLogout'))

    if request.method == "POST":
        db = get_db_connection()
        cursor = db.cursor()

        try:
            consumerId = request.form["consumer-number"]
            billId = request.form["bill-id"]
            dueAmount = request.form["due-amount"]
            
            cursor.execute("SELECT * FROM customers WHERE consumer_id=?", (consumerId, ))
            consumer = cursor.fetchone()

            cursor.execute("SELECT * FROM bills WHERE bill_id=?", (billId, ))
            bill = cursor.fetchone()

            if not consumer and bill:
                return render_template("seperate-bill.html", customer=True, bill=True)
            elif not consumer:
                return render_template("seperate-bill.html", customer=True, bill=False)
            elif bill:
                return render_template("seperate-bill.html", customer=False, bill=True)
            
            cursor.execute("INSERT INTO bills VALUES(?, ?, ?, ?)", (billId, dueAmount, dueAmount, consumerId, ))
            db.commit()
            return render_template("bill-success.html", consumer_id=consumerId, bill_id=billId)
        
        except Exception as e:
            return str(e)
        
        finally:
            db.close()

    else:
        return redirect("/bill")

@app.route("/customerDetails")
def customerDetails():
    if not session["admin"]:
        return redirect(url_for('adminLogout'))
        
    consumer_id = request.args.get("consumer_id")
    name = request.args.get("name")
    email = request.args.get("email")
    mobile = request.args.get("mobile")
    return render_template("customer-details.html", consumer_id=consumer_id, name=name, email=email, mobile=mobile)

@app.route("/deleteCustomer", methods=["GET", "POST"])
def deleteCustomer():
    if not session["admin"]:
        return redirect(url_for('adminLogout'))
        
    if request.method == "POST":
        print("request received")
        db = get_db_connection()
        cursor = db.cursor()

        try:
            consumer_id = request.args.get('consumer_id')
            print(consumer_id)
            cursor.execute("DELETE FROM customers WHERE consumer_id=?", (consumer_id, ))
            db.commit()
            cursor.execute("DELETE FROM bills WHERE consumer_id=?", (consumer_id, ))
            db.commit()
            cursor.execute("DELETE FROM complaints WHERE consumer_id=?", (consumer_id, ))
            db.commit()
            return render_template("delete-success.html", consumer_id=consumer_id)
        
        except Exception as e:
            return str(e)
        
        finally:
            db.close()
    
    else:
        return redirect(url_for("customerDetails"))

@app.route("/addBillPage")
def addBillPage():
    if not session["admin"]:
        return redirect(url_for('adminLogout'))
        
    consumer_id = request.args.get('consumer_id')
    consumer_name = request.args.get('name')
    return render_template("add-bill.html", consumer_id=consumer_id, name=consumer_name)

@app.route("/addBill", methods=['GET', 'POST'])
def addBill():
    if not session["admin"]:
        return redirect(url_for('adminLogout'))
        
    consumer_id = request.args.get('consumer_id')
    consumer_name = request.args.get('name')
    if request.method == "POST":
        db = get_db_connection()
        cursor = db.cursor()

        try:
            bill_id = request.form['bill_id']
            due_amount = request.form['due_amount']
            cursor.execute("SELECT * FROM bills WHERE bill_id=?", (bill_id, ))
            existingBill = cursor.fetchone()

            if existingBill:
                return render_template("add-bill.html", error=True, consumer_id=consumer_id)
            
            cursor.execute("INSERT INTO bills VALUES(?, ?, ?, ?)", (bill_id, due_amount, due_amount, consumer_id))
            db.commit()
            return render_template("bill-success.html", consumer_id=consumer_id, bill_id=bill_id)

        except Exception as e:
            return str(e)

        finally:
            db.close()
    else:
        return redirect(url_for('addBillPage', consumer_id=consumer_id, name=consumer_name))

@app.route("/editComplaintPage")
def editComplaintPage():
    if not session["admin"]:
        return redirect(url_for('adminLogout'))
        
    consumer_id = request.args.get('consumer_id')
    complaint_id = request.args.get('complaint_id')
    problem = request.args.get('problem')
    status = request.args.get('status')
    return render_template("edit-complaint.html", consumer_id=consumer_id, complaint_id=complaint_id, problem=problem, status=status)

@app.route("/editComplaint", methods=['GET', 'POST'])
def editComplaint():
    if not session["admin"]:
        return redirect(url_for('adminLogout'))
        
    consumer_id = request.args.get('consumer_id')
    complaint_id = request.args.get('complaint_id')
    problem = request.args.get('problem')
    prevStatus = request.args.get('prevStatus')
    status = request.form['status']

    db = get_db_connection()
    cursor = db.cursor()

    if request.method=="POST":
        try:
            cursor.execute("UPDATE complaints SET status=? WHERE complaint_id=? AND consumer_id=?", (status, complaint_id, consumer_id))
            db.commit()
            return render_template("complaint-updated.html", complaint_id=complaint_id)

        except Exception as e:
            return str(e)
        
        finally:
            db.close()
    
    else:
        return redirect(url_for('editComplaintPage', consumer_id=consumer_id, complaint_id=complaint_id, problem=problem, status=prevStatus))

@app.route("/adminHome")
def adminHome():
    if not session["admin"]:
        return redirect(url_for('adminLogout'))
        
    db = get_db_connection()
    cursor = db.cursor()

    try:
        cursor.execute("SELECT * FROM customers")
        customers_count = len(cursor.fetchall())
        cursor.execute("SELECT * FROM bills")
        bills_count = len(cursor.fetchall())
        cursor.execute("SELECT * FROM complaints")
        complaints_count = len(cursor.fetchall())
        return render_template("admin-home.html", customers_count=customers_count, bills_count=bills_count, complaints_count=complaints_count)
        
    except Exception as e:
        return str(e)
        
    finally:
        db.close()

@app.route("/adminCustomers")
def adminCustomers():
    if not session["admin"]:
        return redirect(url_for('adminLogout'))
        
    db = get_db_connection()
    cursor = db.cursor()

    try:
        cursor.execute("SELECT consumer_id, customer_name, email, mobile FROM customers")
        customers = cursor.fetchall()
        return render_template("admin-customers.html", customers = customers)

    except Exception as e:
        return str(e)

    finally:
        db.close()

@app.route("/adminBills")
def adminBills():
    if not session["admin"]:
        return redirect(url_for('adminLogout'))

    db = get_db_connection()
    cursor = db.cursor()

    try:
        cursor.execute("SELECT consumer_id, bill_id, due_amount, payable_amount FROM bills ORDER BY consumer_id ")
        bills = cursor.fetchall()
        return render_template("admin-bills.html", bills = bills)
        
    except Exception as e:
        return str(e)
        
    finally:
        db.close()

@app.route("/adminComplaints")
def adminComplaints():
    if not session["admin"]:
        return redirect(url_for('adminLogout'))

    db = get_db_connection()
    cursor = db.cursor()

    try:
        cursor.execute("SELECT consumer_id, complaint_id, problem, status FROM complaints ORDER BY consumer_id ")
        complaints = cursor.fetchall()
        return render_template("admin-complaints.html", complaints = complaints)
        
    except Exception as e:
        return str(e)
        
    finally:
        db.close()

@app.route("/adminLogin", methods = ["GET", "POST"])
def adminLogin():
    if request.method == "POST":
        db = get_db_connection()
        cursor = db.cursor()

        try:
            adminEmail = request.form['adminEmail']
            adminPassword = request.form['adminPassword']

            cursor.execute("SELECT * FROM admins WHERE email=? AND password=?", (adminEmail, adminPassword, ))
            isAdmin = cursor.fetchone()

            session["admin"] = "Admin"

            if not isAdmin:
                return render_template("admin-login.html",  error = True)

            cursor.execute("SELECT * FROM customers")
            customers_count = len(cursor.fetchall())
            cursor.execute("SELECT * FROM bills")
            bills_count = len(cursor.fetchall())
            cursor.execute("SELECT * FROM complaints")
            complaints_count = len(cursor.fetchall())
            return render_template("admin-home.html", customers_count=customers_count, bills_count=bills_count, complaints_count=complaints_count)
        
        except Exception as e:
            return str(e)
        
        finally:
            db.close()
    else:
        return render_template("admin-login.html", error=False)

@app.route("/adminLogout")
def adminLogout():
    session["admin"] = ""
    return render_template("admin-login.html")

@app.route("/")
def base():
    return render_template("base.html")

@app.route("/register")
def register():
    return render_template("register.html")

@app.route("/login")
def login():
    return render_template("index.html")

@app.route("/logout")
def logout():
    session["customer_name"] = ""
    session["consumer_id"] = ""
    return redirect("/login")

@app.route("/forgotPassword")
def forgotPassword():
    return render_template("change-password.html")

@app.route("/changePassword", methods = ["GET", "POST"])
def changePassword():
    if request.method == "POST":
        db = get_db_connection()
        cursor = db.cursor()

        try:
            email = request.form["email"]
            newPassword = request.form["newPassword"]

            cursor.execute("SELECT * FROM customers WHERE email = ?", (email, ))
            existingCustomer = cursor.fetchone()

            if existingCustomer:
                cursor.execute("UPDATE customers SET password = ? WHERE email = ?", (newPassword, email, ))
                db.commit()
                return redirect(url_for("login"))

            return render_template("change-password.html", error = True)            

        except Exception as e:
            return str(e)
        
        finally:
            db.close()
    
    else:
        return redirect(url_for("forgotPassword"))

@app.route("/home")
def home():
    if not session["customer_name"]:
        return redirect(url_for('login'))

    return render_template("home.html", customer_name=session["customer_name"])

@app.route("/registerComplaint", methods = ["GET", "POST"])
def registerComplaint():
    if not session["customer_name"]:
        return redirect(url_for('login'))

    if request.method == "POST":
        db = get_db_connection()
        cursor = db.cursor()

        try:
            complaint_type = request.form["complaintType"]
            category = request.form["category"]
            contact_person = request.form['contactPerson']
            mobile = request.form['mobile']
            landmark = request.form['landmark']
            problem = request.form['problemDesc']
            address = request.form['address']
            status = "unsolved"
            consumer_id = session["consumer_id"]

            complaint_id = random.randint(10000,99999)

            cursor.execute("INSERT INTO complaints VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", (complaint_id, complaint_type, category, contact_person, int(mobile), landmark, problem, address, status, consumer_id))

            db.commit()

            return render_template("complaint-success.html", complaint_id=complaint_id, customer_name=session["customer_name"])

            # return render_template("complaint.html", complaint_id=complaint_id, customer_name=session["customer_name"])

        except Exception as e:
            return str(e)
        
        finally:
            db.close()
    
    else:
        return render_template("complaint.html", customer_name=session["customer_name"])

@app.route("/complaintStatus", methods = ["GET", "POST"])
def complaintStatus():
    if not session["customer_name"]:
        return redirect(url_for('login'))

    if request.method == "POST":
        db = get_db_connection()
        cursor = db.cursor()

        try:
            complaint_id = request.form['complaint_id']

            if not complaint_id:
                return render_template('status.html', msg = "no input", status = "", customer_name=session["customer_name"])
            
            cursor.execute("SELECT status FROM complaints WHERE complaint_id = ?", (complaint_id, ))
            complaint = cursor.fetchone()

            if not complaint:
                return render_template('status.html', msg = "no complaint", status = "", customer_name=session["customer_name"])
            
            return render_template('status.html', msg = "complaint", status = complaint[0], customer_name=session["customer_name"])

        except Exception as e:
            return str(e)
        
        finally:
            db.close()
    
    else:
        return render_template("status.html", customer_name=session["customer_name"])

@app.route("/payment")
def payment():
    if not session["customer_name"]:
        return redirect(url_for('login'))

    db = get_db_connection()
    cursor = db.cursor()
    try:
        consumer_id = session["consumer_id"]
        cursor.execute("SELECT * FROM bills WHERE consumer_id = ?", (consumer_id, ))

        bills = cursor.fetchall()
        session['bills'] = bills
        
        cursor.execute("SELECT SUM(due_amount) FROM bills WHERE consumer_id = ?", (consumer_id, ))
        totalAmount = cursor.fetchone()[0]

        return render_template("payment.html", bills=bills, customer_name=session["customer_name"], totalAmount=totalAmount)

    except Exception as e:
        return str(e)
    
    finally:
        db.close()

@app.route("/billPayment", methods = ["GET", "POST"])
def billPayment():
    if not session["customer_name"]:
        return redirect(url_for('login'))

    if request.method == "POST":
        try:
            bill_id = request.form["bill_id"]
            due_amount = request.form["due_amount"]
            payable_amount = request.form["payable_amount"]
            return render_template("bill-payment.html", consumer_id=session["consumer_id"], bill_id=bill_id, due_amount=due_amount,payable_amount=payable_amount,customer_name=session["customer_name"])

        except Exception as e:
            return str(e)
        
        finally:
            pass
        
    else:
        return redirect(url_for("payment"))

@app.route("/cardDetails", methods = ["GET", "POST"])
def cardDetails():
    if not session["customer_name"]:
        return redirect(url_for('login'))

    if request.method == "POST":
        card_type = request.form.get("card-type")
        bill_id = request.form["bill_id"]
        payable_amount = request.form["payable_amount"]

        return render_template("card-details.html", card_type=card_type.capitalize(), bill_id=bill_id, payable_amount=payable_amount, customer_name=session["customer_name"])

    else:
        return redirect(url_for("billPayment"))

@app.route("/makePayment", methods = ["GET", "POST"])
def makePayment():
    if not session["customer_name"]:
        return redirect(url_for('login'))

    if request.method == "POST":
        db = get_db_connection()
        cursor = db.cursor()
        
        try:
            bill_id = request.form["bill_id"]
            payable_amount = request.form["payable_amount"]
            card_type = request.form["card_type"].capitalize()
            time = datetime.now()
            time = time.strftime("%b %d, %Y")
            card_number = request.form["card_number"]
            transaction_number = random.randint(100000000, 999999999)
            receipt_number = random.randint(10000000, 99999999)  
            
            
            cursor.execute("UPDATE bills SET due_amount = ? WHERE bill_id = ?", (0.00, bill_id, ))
            db.commit()

            return render_template("payment-success.html", bill_id=bill_id, payable_amount=payable_amount, card_type=card_type, consumer_id=session["consumer_id"], customer_name=session["customer_name"], time=time, transaction_number=transaction_number, receipt_number=receipt_number)            

        except Exception as e:
            return str(e)

        finally:
            db.close()

    else:
        return redirect(url_for("cardDetails"))

@app.route("/updateCustomerPage")
def updateCustomerPage():
    if not session["customer_name"]:
        return redirect(url_for('login'))
    
    db = get_db_connection()
    cursor = db.cursor()

    try:
        cursor.execute("SELECT consumer_id, title, customer_name, email, mobile, user_id FROM customers WHERE consumer_id=?", (session['consumer_id'], ))
        customer = cursor.fetchone()
        return render_template("update-customer.html", customer_name=session['customer_name'], customer=customer)
    
    except Exception as e:
        return str(e)
    
    finally:
        db.close()
    
@app.route("/updateCustomerDetails", methods=["GET", "POST"])
def updateCustomerDetails():
    if not session["customer_name"]:
        return redirect(url_for('login'))

    if request.method == "POST":
        db = get_db_connection()
        cursor = db.cursor()

        try:
            email = request.form['email']
            mobile = request.form['mobile']

            cursor.execute("UPDATE customers SET email=?, mobile=? WHERE consumer_id=?", (email, mobile, session['consumer_id']))
            db.commit()

            return render_template("update-success.html")

        except Exception as e:
            return str(e)
        
        finally:
            db.close()


@app.route("/homeAfterRegister", methods=["GET", "POST"])
def homeAfterRegister():
    if request.method == "POST":
        db = get_db_connection()
        cursor = db.cursor()
        try:
            consumer_id = request.form["consumer-id"]
            title = request.form["titleType"]
            customer_name = request.form["customer-name"]
            email = request.form["email"]
            mobile = request.form["mobile"]
            user_id = request.form["userID"]
            password = request.form["password"]
            confirm_password = request.form["confirmPassword"]            

            cursor.execute("SELECT * FROM customers WHERE consumer_id = ?", (consumer_id, ))
            existingCustomer = cursor.fetchone()

            if existingCustomer:
                return render_template("register.html", fail = True, field = "consumer_id")

            cursor.execute("SELECT * FROM customers WHERE email = ?", (email, ))
            existingCustomer = cursor.fetchone()

            if existingCustomer:
                return render_template("register.html", fail = True, field = "email")

            cursor.execute("SELECT * FROM customers WHERE mobile = ?", (mobile, ))
            existingCustomer = cursor.fetchone()

            if existingCustomer:
                return render_template("register.html", fail = True, field = "mobile")
            
            cursor.execute("SELECT * FROM customers WHERE user_id = ?", (user_id, ))
            existingCustomer = cursor.fetchone()

            if existingCustomer:
                return render_template("register.html", fail = True, field = "user_id")
            
            if password != confirm_password:
                return render_template("register.html", fail = True, field = "password")
            
            cursor.execute("INSERT INTO customers VALUES(?, ?, ?, ?, ?, ?, ?)", (consumer_id, title, customer_name, email, mobile, user_id, password))
            db.commit()
            session["consumer_id"] = consumer_id
            session["customer_name"] = customer_name
            return render_template("register-success.html", consumer_id=consumer_id, title=title, customer_name=customer_name, mobile=mobile, customerName=session["customer_name"])

        except Exception as e:
            return str(e)
        
        finally:
            db.close()
    else:
        return render_template("register.html")


@app.route("/homeAfterLogin", methods=["GET", "POST"])
def homeAfterLogin():
    if request.method == "POST":
        db = get_db_connection()
        cursor = db.cursor()
        try:
            email = request.form["email"]
            password = request.form["password"]

            cursor.execute("SELECT * FROM customers WHERE email = ? AND password = ?", (email, password))
            existingCustomer = cursor.fetchone()

            if existingCustomer:
                cursor.execute("SELECT consumer_id FROM customers WHERE email = ?", (email, ))
                session["consumer_id"] = cursor.fetchone()[0]
                cursor.execute("SELECT customer_name FROM customers WHERE email = ?", (email, ))
                session["customer_name"] = cursor.fetchone()[0]
                return render_template("home.html", customer_name=session["customer_name"])
            
            return render_template("index.html", nocustomer = True)

        except Exception as e:
            return str(e)

        finally:
            db.close()
    else:
        return render_template("index.html")

def get_db_connection():
    if 'db_connection' not in g:
        g.db_connection = sqlite3.connect("tables.db")
        # g.db_connection.row_factory = sqlite3.Row
    return g.db_connection

@app.teardown_appcontext
def close_db_connection(exception=None):
    db = g.pop("db_connection", None)
    if db is not None:
        db.close()

adminList = [('rambabu@gmail.com', 'rambabu@admin'),
            ('rakesh@gmail.com', 'rakesh@admin'),
            ('sairam@gmail.com', 'sairam@admin'),
            ('durgaprasad@gmail.com', 'durgaprasad@admin'),]

custList = [(1234567890121, "Mr.", "Sagar", "sagar@gmail.com", 7787879899, "Sagar@18", "Sagar@18"),
         (1234567890122, "Mr.", "Pardhu", "pardhu@gmail.com", 9787879899, "Pardhu@28", "Pardhu@28"),
         (1234567890123, "Mr.", "Shanmukh", "shanmukh@gmail.com", 8787879899, "shanmukh@87", "shanmukh@87"),
         (1234567890124, "Mr.", "Harsha", "harsha@gmail.com", 9987879899, "harsha@01", "harsha@01"),
         (1234567890125, "Mr.", "Veera", "veera@gmail.com", 8887879899, "veera@07", "veera@07"),
         (1234567890126, "Mr.", "Satya", "satya@gmail.com", 7787879009, "satya@02", "satya@02"),
         (1234567890127, "Mr.", "Bhavishya", "bhavishya@gmail.com", 7787009899, "bhavishya@11", "bhavishya@11"),
         (1234567890128, "Mr.", "Varshit", "varshit@gmail.com", 7787876799, "varshit@29", "varshit@29"),
         (1234567890129, "Mr.", "Hasan", "hasan@gmail.com", 6687879899, "hasan@25", "hasan@25"),
         (1234567890120, "Mr.", "Rithik", "rithik@gmail.com", 7787879449, "rithik@99", "rithik@99"),]

billsList = [(12341, 1000.00, 1000.00, 1234567890121), (12342, 1000.00, 1000.00, 1234567890121),
            (12343, 1000.00, 1000.00, 1234567890122), (12344, 1000.00, 1000.00, 1234567890122),
            (12345, 1000.00, 1000.00, 1234567890123), (12346, 1000.00, 1000.00, 1234567890123),
            (12347, 1000.00, 1000.00, 1234567890124), (12348, 1000.00, 1000.00, 1234567890124),
            (12349, 1000.00, 1000.00, 1234567890125), (12340, 1000.00, 1000.00, 1234567890125),
            (22341, 1000.00, 1000.00, 1234567890126), (22342, 1000.00, 1000.00, 1234567890126),
            (22343, 1000.00, 1000.00, 1234567890127), (22344, 1000.00, 1000.00, 1234567890127),
            (22345, 1000.00, 1000.00, 1234567890128), (22346, 1000.00, 1000.00, 1234567890128),
            (22347, 1000.00, 1000.00, 1234567890129), (22348, 1000.00, 1000.00, 1234567890129),
            (22349, 1000.00, 1000.00, 1234567890120), (22340, 1000.00, 1000.00, 1234567890120),]

def init_db():
    try:
        with app.app_context():
            db = get_db_connection()
            cur = db.cursor()
            cur.execute('''
                CREATE TABLE IF NOT EXISTS admins (
                    email TEXT PRIMARY KEY,
                    password TEXT NOT NULL
                )''')
            db.commit()
            cur.execute('''
                CREATE TABLE IF NOT EXISTS customers (
                    consumer_id INTEGER PRIMARY KEY,
                    title TEXT NOT NULL,
                    customer_name TEXT NOT NULL,
                    email TEXT UNIQUE NOT NULL,
                    mobile INTEGER UNIQUE NOT NULL,
                    user_id TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL
                )
            ''')
            db.commit()
            cur.execute('''
                CREATE TABLE IF NOT EXISTS bills (
                    bill_id INTEGER PRIMARY KEY,
                    due_amount REAL NOT NULL,
                    payable_amount REAL NOT NULL,
                    consumer_id INTEGER NOT NULL,
                    FOREIGN KEY (consumer_id) REFERENCES customers(consumer_id)
                )
            ''')
            db.commit()
            cur.execute('''
                CREATE TABLE IF NOT EXISTS complaints (
                    complaint_id INTEGER PRIMARY KEY,
                    complaint_type TEXT,
                    category TEXT,
                    contact_person TEXT,
                    mobile INTEGER NOT NULL,
                    landmark TEXT,
                    problem TEXT,
                    address TEXT,
                    status TEXT DEFAULT "Unsolved" NOT NULL,
                    consumer_id INTEGER NOT NULL,
                    FOREIGN KEY (consumer_id) REFERENCES customers(consumer_id)
                )
            ''')
            db.commit()
            cur.executemany("INSERT INTO admins VALUES (?, ?)", adminList)
            db.commit()
            cur.executemany("INSERT INTO customers VALUES (?, ?, ?, ?, ?, ?, ?)", custList)
            db.commit()
            cur.executemany("INSERT INTO bills VALUES (?, ?, ?, ?)", billsList)
            db.commit()
    except sqlite3.Error as e:
        print("SQLite error:", e)

init_db()

if __name__ == "__main__":
    app.run(debug=True)
